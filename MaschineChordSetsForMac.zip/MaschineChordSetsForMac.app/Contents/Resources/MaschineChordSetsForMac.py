import PySimpleGUI as sg

# Choose a Theme for the Layout
sg.theme('DarkGrey4')
font = ("Verdana", 13)

keyValues = ["C", "C#", "D", "Eb ", "E", "F", "F#", "G", "Ab ", "A", "Bb ", "B", ""]
chordsetValues = ["Maj 1", "Maj 2", "Maj 3", "Maj 4", "Maj 5", "Maj 6", "Maj 7", "Maj 8", "Min 1", "Min 2", "Min 3", "Min 4", "Min 5", "Min 6", "Min 7", "Min 8"]

## Chordset data
# Row 0 is the root of the chord, indexed from keyValues (starts at C)
# Row 1 is the modifier
# Row 2 is the note of any 'slash' chord, indexed from keyValues, value of 12 just pulls a blank from the end of that tuple
maj1data = [[0, 4, 5, 7, 9, 4, 7, 2, 5, 5, 7, 7],["", "mi", "", "", "mi", "sus4", "add9", "mi", "add9", "6", "sus4", ""],[12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12]]
maj2data = [[0, 0, 0, 0, 5, 5, 0, 9, 4, 5, 7, 7],["", "/", "/", "/", "add9", "mi", "sus4", "mi7", "mi", "", "sus4", "6"],[12, 11, 9, 7, 12, 12, 12, 12, 12, 12, 12, 12]]
maj3data = [[0, 9, 5, 7, 9, 5, 0, 7, 2, 10, 7, 5],["", "mi", "ma7", "sus4", "mi add9", "6", "sus2", "", "sus2", "add9", "sus4", "add9"],[12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12]]
maj4data = [[0, 7, 9, 5, 5, 9, 2, 9, 7, 9, 7, 2],["", "", "mi", "6", "", "mi/", "mi7", "mi/", "add9", "mi7", "/", "mi/"],[12, 12, 12, 12, 12, 4, 12, 0, 12, 12, 11, 7]]
maj5data = [[0, 2, 5, 0, 8, 3, 10, 5, 7, 10, 5, 0],["", "", "", "", "", "", "", "", "7 sus4", "add9", "6", "add9"],[12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12]]
maj6data = [[0, 7, 2, 9, 5, 7, 0, 9, 2, 4, 0, 7],["", "", "mi", "mi", "", "/", "/", "mi7", "mi7", "mi7", "/", "sus4"],[12, 12, 12, 12, 12, 5, 4, 12, 12, 12, 5, 12]]
maj7data = [[0, 7, 9, 4, 5, 0, 2, 2, 7, 7, 5, 7],["", "", "mi", "mi", "", "/", "mi", "mi/", "7/", "", "/", "7/"],[12, 12, 12, 12, 12, 4, 12, 0, 11, 12, 9, 11]]
maj8data = [[0, 1, 2, 3, 4, 0, 5, 10, 4, 9, 2, 7],["ma9", "dim", "mi9", "dim7", "mi9", "9#5", "ma7 add13", "9", "mi7", "9", "mi11", "7 (b9, b13)"],[12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12]]
min1data = [[0, 0, 5, 7, 8, 3, 7, 10, 5, 5, 0, 7],["mi", "mi/", "mi", "", "ma7", "", "mi", "", "", "mi/", "mi/", ""],[12, 3, 12, 12, 12, 12, 12, 12, 12, 8, 7, 12]]
min2data = [[0, 7, 0, 0, 8, 3, 5, 10, 0, 10, 8, 7],["mi", "+/", "mi/", "mi/", "ma7", "ma7", "mi", "7", "mi", "add9", "add9", "7 sus4"],[12, 11, 10, 9, 12, 12, 12, 12, 12, 12, 12, 12]]
min3data = [[0, 8, 3, 10, 5, 5, 0, 7, 0, 0, 0, 0],["mi", "", "", "", "", "mi", "mi/", "sus4", "mi", "mi#5", "mi6", "mi7"],[12, 12, 12, 12, 12, 12, 7, 12, 12, 12, 12, 12]]
min4data = [[0, 3, 10, 5, 8, 8, 8, 3, 2, 2, 5, 7],["mi", "", "", "", "", "ma7", "mi7", "ma7", "sus4", "", "mi/", "+"],[12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 7, 12]]
min5data = [[0, 10, 8, 10, 0, 2, 0, 5, 7, 8, 11, 0],["mi", "", "6", "add9", "mi", "mi7", "mi/", "mi", "", "ma7", "6/9", "sus4"],[12, 12, 12, 12, 12, 12, 3, 12, 12, 12, 12, 12]]
min6data = [[0, 5, 10, 3, 8, 2, 7, 7, 8, 7, 0, 7],["mi", "mi", "", "", "", "mi7 b5", "add9 b9", "", "/", "7", "mi/", "7 b9"],[12, 12, 12, 12, 12, 12, 12, 12, 7, 12, 7, 12]]
min7data = [[0, 8, 0, 0, 5, 3, 0, 9, 8, 7, 0, 7],["mi9", "9", "mi11", "7 (#9,b13)", "mi9", "ma7/", "11", "mi11", "7#11", "7#9", "mi add9", "7 (b9,b13)"],[12, 12, 12, 12, 12, 5, 12, 12, 12, 12, 12, 12]]
min8data = [[0, 2, 0, 0, 5, 8, 3, 10, 9, 8, 7, 0],["mi6/9", "mi7 b5", "mi11/", "mi9", "mi9", "mi7", "mi7", "mi7 b5", "mi11", "ma7#5", "7 (b9,b13)", "mi9 ma7"],[12, 12, 7, 12, 12, 12, 12, 12, 12, 12, 12, 12]]

#...pulling the chordset data together into one array...
chordData = [maj1data, maj2data, maj3data, maj4data, maj5data, maj6data, maj7data, maj8data, min1data, min2data, min3data, min4data, min5data, min6data, min7data, min8data]

col1=[[sg.Text("", key=f"-CHORD{9}-", pad=(10,10))],[sg.Text("", key=f"-CHORD{5}-", pad=(10,10))],[sg.Text("", key=f"-CHORD{1}-", pad=(10,10))]]
col2=[[sg.Text("", key=f"-CHORD{10}-", pad=(10,10))],[sg.Text("", key=f"-CHORD{6}-", pad=(10,10))],[sg.Text("", key=f"-CHORD{2}-", pad=(10,10))]]
col3=[[sg.Text("", key=f"-CHORD{11}-", pad=(10,10))],[sg.Text("", key=f"-CHORD{7}-", pad=(10,10))],[sg.Text("", key=f"-CHORD{3}-", pad=(10,10))]]
col4=[[sg.Text("", key=f"-CHORD{12}-", pad=(10,10))],[sg.Text("", key=f"-CHORD{8}-", pad=(10,10))],[sg.Text("", key=f"-CHORD{4}-", pad=(10,10))]]

layout = [
    [[sg.Column(col1, element_justification='c' ), sg.Column(col2, element_justification='c'),
    sg.Column(col3, element_justification='c'), sg.Column(col4, element_justification='c')],
    [sg.Text("Key:", pad=((10,0),(0,0))), sg.Combo(keyValues, default_value=keyValues[0], key="-KEYCOMBO-", enable_events=True),
    sg.Text("Chord Set:", pad=((10,0),(0,0))), sg.Combo(chordsetValues, default_value=chordsetValues[0], key="-CHORDSETCOMBO-", enable_events=True)]
    ]
]

window = sg.Window("Maschine Chord Sets", layout, finalize=True, font=font)

def generate_chords(values):
    currentKey = keyValues.index(values["-KEYCOMBO-"])
    currentChordset = chordsetValues.index(values["-CHORDSETCOMBO-"])

    for i in range(12):
        keyIndex = (i + currentKey) % 12
        print ('keyIndex = ', keyIndex)

        # Main part of chord (e.g. "A" for Asus4)
        chordpartAindex = (currentKey + chordData[currentChordset][0][i]) % 12
        print ('chordpartAindex = ', chordpartAindex)
        chordpartA = keyValues[chordpartAindex]

        # Modifier (e.g. "sus4", "mi add9", "ma7#5", whatever...)
        chordpartB = chordData[currentChordset][1][i]

        # Secondary chord (e.g. slash chords)
        if chordData[currentChordset][2][i] == 12:
            chordpartCindex = 12
        else:
            chordpartCindex = (currentKey + chordData[currentChordset][2][i]) % 12
        print ('chordpartCindex = ', chordpartCindex)
        chordpartC = keyValues[chordpartCindex]
        
        chord = chordpartA + chordpartB + chordpartC
        window[f"-CHORD{i+1}-"].update(chord)
    
while True:
    event, values = window.read()
    if event == sg.WINDOW_CLOSED:
        break
    if event == "-KEYCOMBO-":
        generate_chords(values)
    if event == "-CHORDSETCOMBO-":
        generate_chords(values)

window.close()
